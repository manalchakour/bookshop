let books = {
    1: {"author": "Harper Lee","title": "To Kill a Mockingbird", "reviews": {} },
    2: {"author": "F. Scott Fitzgerald","title": "The Great Gatsby", "reviews": {} },
    3: {"author": "Gabriel García Márquez","title": "One Hundred Years of Solitude", "reviews": {} },
    4: {"author": "E.M. Forster","title": "A Passage to India", "reviews": {} },
    5: {"author": "Ralph Ellison","title": "Invisible Man", "reviews": {} },
    6: {"author": "Miguel de Cervantes","title": "Don Quixote", "reviews": {} },
    7: {"author": "Mohamed Choukri","title": "le PAIN NU ", "reviews": {} },
    8: {"author": "Jane Austen","title": "Pride and Prejudice", "reviews": {} },
    9: {"author": "Ahmed Sefrioui ","title": "la boite a merveille", "reviews": {} },
    10: {"author": "Zohra Rmij","title": "Azzouza", "reviews": {} }
}

module.exports=books;